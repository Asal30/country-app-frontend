export default function UserDashboard() {
    return (
        <div>
            <h1>User Dashboard</h1>
        </div>
    );
}
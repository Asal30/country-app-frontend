import HomePage from "../pages/homePage";
export default function UserDashboard() {
    return (
        <div>
            <HomePage />
        </div>
    );
}